WorldLoaded = function()
	print("GLOBAL SCRIPT: WorldLoaded called!")
end
